package com.pep.task1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Controller {
	private List<Book> books = new ArrayList<>();

	public void addBook(Book book) {
		books.add(book);
		System.out.println("Book added: " + book.getName());
	}

	public void removeBook(String title) {
		Iterator<Book> iterator = books.iterator();
		while (iterator.hasNext()) {
			Book book = iterator.next();
			if (book.getName().equalsIgnoreCase(title)) {
				iterator.remove();
				System.out.println("Book removed: " + title);
				return;
			}
		}
		System.out.println("Book not found: " + title);
	}

	public void searchBook(String title) {
		for (Book book : books) {
			if (book.getName().equalsIgnoreCase(title)) {
				String status = book.isAvailable() ? "Available" : "Borrowed";
				System.out.println("Found: " + book.getName() + " (" + status + ")");
				return;
			}
		}
		System.out.println("Book not found: " + title);
	}

	public void displayAllBooks() {
		if (books.isEmpty()) {
			System.out.println("No books in the library.");
			return;
		}
		System.out.println("Books in the library:");
		for (Book book : books) {
			String status = book.isAvailable() ? "Available" : "Borrowed";
			System.out.println("- " + book.getName() + " by " + book.getAuthor() + " (" + status + ")");
		}
	}

	public void borrowBook(String title) {
		for (Book book : books) {
			if (book.getName().equalsIgnoreCase(title) && book.isAvailable()) {
				book.setAvailable(false);
				System.out.println("You borrowed: " + book.getName());
				return;
			}
		}
		System.out.println("Sorry, the book is not available.");
	}

	public void returnBook(String title) {
		for (Book book : books) {
			if (book.getName().equalsIgnoreCase(title) && !book.isAvailable()) {
				book.setAvailable(true);
				System.out.println("You returned: " + book.getName());
				return;
			}
		}
		System.out.println("This book was not borrowed from our library.");
	}
}