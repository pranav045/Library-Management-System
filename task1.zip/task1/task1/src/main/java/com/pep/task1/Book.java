package com.pep.task1;

class Book {
	private int id;
	private String name;
	private String author;
	private boolean isAvailable;

	public Book(int id, String name, String author) {
		this.id = id;
		this.name = name;
		this.author = author;
		this.isAvailable = true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
}