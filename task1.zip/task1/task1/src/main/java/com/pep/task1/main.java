package com.pep.task1;

import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Controller library = new Controller();
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("\nMenu:");
			System.out.println("1. Add Book");
			System.out.println("2. Remove Book");
			System.out.println("3. Search Book");
			System.out.println("4. Display All Books");
			System.out.println("5. Return Book");
			System.out.println("6. Borrow Book");
			System.out.println("7. Exit");
			System.out.print("Choose an option: ");

			int choice = sc.nextInt();
			sc.nextLine(); // consume newline

			switch (choice) {
			case 1:
				System.out.print("Enter ID: ");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.print("Enter Name: ");
				String name = sc.nextLine();
				System.out.print("Enter Author: ");
				String author = sc.nextLine();
				library.addBook(new Book(id, name, author));
				break;
			case 2:
				System.out.print("Enter Book Name to Remove: ");
				library.removeBook(sc.nextLine());
				break;
			case 3:
				System.out.print("Enter Book Name to Search: ");
				library.searchBook(sc.nextLine());
				break;
			case 4:
				library.displayAllBooks();
				break;
			case 5:
				System.out.print("Enter Book Name to Return: ");
				library.returnBook(sc.nextLine());
				break;
			case 6:
				System.out.print("Enter Book Name to Borrow: ");
				library.borrowBook(sc.nextLine());
				break;
			case 7:
				System.out.println("Exiting...");
				sc.close();
				return;
			default:
				System.out.println("Invalid choice.");
			}
		}
	}

}
